import React from "react";

function Communities() {
  return <div>Communities</div>;
}

export default Communities;
