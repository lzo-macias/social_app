import React from "react";
import CreateCommunity from "../components/CreateCommunityComponent";

function CreateCommunityPage() {
  return (
    <div>
      <h1>Create a New Community</h1>
      <CreateCommunity />
    </div>
  );
}

export default CreateCommunityPage;
