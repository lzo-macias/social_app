import React from "react";
import { useParams } from "react-router-dom";
import CreatePostComponent from "./CreatePostComponent";
import FetchAllPostByUserIdComponent from "./FetchAllPostByUserIdComponent";

const PersonalPostComponent = () => {
  const { userId } = useParams(); // Extract userId from the URL
  console.log("📢 Extracted userId from URL in Album:", userId);
  return (
    <div>
      <CreatePostComponent />
      <FetchAllPostByUserIdComponent userId={userId} key={userId} />
    </div>
  );
};

export default PersonalPostComponent;
