import React, { useState, useEffect } from "react";
import axios from "axios";

const UserImageLibrary = () => {
  const [images, setImages] = useState([]);
  const [error, setError] = useState(null);
  const token = localStorage.getItem("token");

  useEffect(() => {
    const fetchImages = async () => {
      try {
        console.log("🚀 Fetching user images...");

        const response = await axios.get(
          "http://localhost:5000/api/images/user-images",
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );

        console.log("✅ Fetched Images:", response.data);
        setImages(response.data);
      } catch (err) {
        console.error("❌ Error fetching user images:", err);
        setError("Failed to fetch user images.");
      }
    };

    fetchImages();
  }, [token]);

  return (
    <div>
      <h2>Your Uploaded Images</h2>
      {error && <p style={{ color: "red" }}>{error}</p>}
      <div>
        {images.length > 0 ? (
          images.map((image) => (
            <img
              key={image.id}
              src={`http://localhost:5000${image.filepath}`} // ✅ Ensure the filepath is correct
              alt="Uploaded"
              style={{ maxWidth: "100px", margin: "5px" }}
            />
          ))
        ) : (
          <p>No images uploaded yet.</p>
        )}
      </div>
    </div>
  );
};

export default UserImageLibrary;
